package com.example;

public class ServerMain {
    public static void main(String[] args) {
        MultiServer server = new MultiServer();
        server.startServer();
    }
}
