package com.example;

public class ClientMain {
    public static void main(String[] args) {
        Client client = new Client();
        client.connetti();
        client.comunica();
    }
}